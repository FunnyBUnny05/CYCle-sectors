# Sector Z-Score Dashboard

Live dashboard showing rolling returns for any sector ETF relative to a benchmark (SPY/QQQ/IWM), normalized as Z-scores.

![Dashboard Preview](https://via.placeholder.com/800x400/0a0a0f/ffffff?text=Sector+Z-Score+Dashboard)

## Features

- **19 Pre-loaded Sector ETFs** - All SPDR sectors + popular industry ETFs
- **Custom Ticker Support** - Add any ETF/stock you want
- **Multiple Benchmarks** - SPY, QQQ, IWM, VTI
- **Configurable Parameters** - 1-5 year returns, 5-20 year Z-score windows
- **Live Data** - Yahoo Finance (primary) + Stooq (fallback)
- **6-Hour Caching** - Reduces API calls
- **Persistent State** - Your selections saved in localStorage

## Available Sectors

| Ticker | Name | Ticker | Name |
|--------|------|--------|------|
| XLB | Materials | XLE | Energy |
| XLF | Financials | XLI | Industrials |
| XLK | Technology | XLP | Consumer Staples |
| XLU | Utilities | XLV | Healthcare |
| XLY | Consumer Disc | XLRE | Real Estate |
| XLC | Communication | SMH | Semiconductors |
| XHB | Homebuilders | XOP | Oil & Gas E&P |
| XME | Metals & Mining | KRE | Regional Banks |
| XBI | Biotech | ITB | Home Construction |
| IYT | Transportation | | |

---

## 🚀 Deploy to GitHub Pages (Step-by-Step)

### Step 1: Create GitHub Account (if needed)
1. Go to [github.com](https://github.com)
2. Click "Sign up" and create an account

### Step 2: Create New Repository
1. Click the **+** icon in the top right → **New repository**
2. Name it: `sector-zscore` (or whatever you want)
3. Make sure **Public** is selected
4. Click **Create repository**

### Step 3: Upload Files
1. On your new repo page, click **"uploading an existing file"** link
2. Drag and drop both files:
   - `index.html`
   - `app.js`
3. Scroll down and click **Commit changes**

### Step 4: Enable GitHub Pages
1. Go to **Settings** (tab at top of repo)
2. Scroll down to **Pages** (left sidebar)
3. Under "Source", select **Deploy from a branch**
4. Under "Branch", select **main** and **/ (root)**
5. Click **Save**

### Step 5: Access Your Site
1. Wait 1-2 minutes for deployment
2. Your site will be live at:
   ```
   https://YOUR-USERNAME.github.io/sector-zscore/
   ```
3. The URL appears at the top of the Pages settings

---

## Alternative: Using Git Command Line

```bash
# 1. Clone the empty repo
git clone https://github.com/YOUR-USERNAME/sector-zscore.git
cd sector-zscore

# 2. Copy the files into the folder
# (copy index.html and app.js here)

# 3. Commit and push
git add .
git commit -m "Initial commit"
git push origin main

# 4. Enable Pages in GitHub Settings (Step 4 above)
```

---

## Files

```
sector-zscore/
├── index.html   # Main page + styling
├── app.js       # Data fetching, calculations, charts
└── README.md    # This file
```

## How It Works

1. Fetches weekly price data from Yahoo Finance (with Stooq fallback)
2. Calculates N-year rolling returns for sector and benchmark
3. Computes relative return (sector return - benchmark return)
4. Normalizes to Z-score using M-year rolling mean/std
5. Displays as interactive charts with signal classifications

## Signal Interpretation

| Signal | Z-Score | Meaning |
|--------|---------|---------|
| CYCLICAL LOW | < -2 | Extreme underperformance, historically precedes outperformance |
| CHEAP | -2 to -1 | Below average relative performance |
| NEUTRAL | -1 to +1 | Normal range |
| EXTENDED | > +1 | Above average, potentially stretched |

## Troubleshooting

**Data not loading?**
- Refresh the page
- Check browser console for errors
- Yahoo Finance may be rate-limiting - wait a few minutes

**Charts look wrong?**
- Try a different Z-score window
- Some newer ETFs have limited history

## License

MIT - Use freely for personal/commercial purposes.
